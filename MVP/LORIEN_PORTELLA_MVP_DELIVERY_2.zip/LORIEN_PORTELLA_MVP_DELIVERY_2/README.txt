MVP of the Connect 3 Game for Advanced Unity Programming for Movile of Level Up

by: Lorién Portella López

How to play: Open LevelScene. The player has a limited set of moves and needs to destroy X amount of tiles of each color.
Touch the screen (or use the simulator on the UnityEditor), and swap in a certain direction to try and switch two tiles. If the swap can be done, the tiles will swap
and the board will collapse.
By matching 4 of the same type in a row, the player will create a missile, and if the player matches 5 tiles in a cross shape, a bomb will be created.
To activate this special tiles, the player must press them.
